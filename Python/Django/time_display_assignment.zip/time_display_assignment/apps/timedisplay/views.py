from django.shortcuts import render
import datetime
#CONTROLLER
#these are the handler functions that my routes proccess
# Create your views here.
def index(request):
	dict = {
		"time": datetime.datetime.now()
	}
	return render(request,'timedisplay/index.html', dict)