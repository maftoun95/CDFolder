$(function() {
	for(var i =1; i <= 151; i++){
		var pokepic = `<div><img id="${i}" src="http://pokeapi.co/media/img/${i}.png"></div>`
		$('body').append(pokepic);
	}
})